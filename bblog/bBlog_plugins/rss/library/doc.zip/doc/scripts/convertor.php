<?php
  function page_convert($strData){
    global $body_conv;
    if (!is_object($body_conv)) $body_conv = new convertor('W1250','UTF8');
    $body_conv->push($strData);
    return $body_conv->pull();
  }
  
  function formdata_convert($strData){
    global $form_conv;
    if (!is_object($form_conv)) $form_conv = new convertor('UTF8','W1250');
    $form_conv->push($strData);
    return $form_conv->pull();
  }

  error_reporting(E_ALL);
  ini_set('display_errors',"1");
  require_once('cls!convertor.php');
  ob_start('page_convert');


  $text = isset($_REQUEST['text']) ? formdata_convert($_REQUEST['text']) : "";
  $from = isset($_REQUEST['from']) ? $_REQUEST['from'] : "W1250";
  $to   = isset($_REQUEST['to'])   ? $_REQUEST['to']   : "UTF8";
  

  echo "<?xml version='1.0' encoding='utf-8'?>"
  
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
 "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="cs" lang="cs">
<head>
<title>pavouk.net .:. convertor</title>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<meta http-equiv="Content-Language" content="cs" />
<link rel="stylesheet" type="text/css" href="/css/standard_style.css" />
</head>
<body>

<form method='post' style='display:inline' action='convertor.php'>
<table style='height:100%;width:100%'><tr><td>
From: 
<select name='from'>
<option value='W1250' <?php if($from=="W1250") echo "selected='selected'"; ?>>windows-1250</option>
<option value='I88592' <?php if($from=="I88592") echo "selected='selected'"; ?>>iso-8895-2</option>
<option value='UTF8' <?php if($from=="UTF8") echo "selected='selected'"; ?>>utf-8</option>
<option value='UE' <?php if($from=="UE") echo "selected='selected'"; ?>>Unicode entities</option>
</select>
To: 
<select name='to'>
<option value='W1250' <?php if($to=="W1250") echo "selected='selected'"; ?>>windows-1250</option>
<option value='I88592' <?php if($to=="I88592") echo "selected='selected'"; ?>>iso-8895-2</option>
<option value='UTF8' <?php if($to=="UTF8") echo "selected='selected'"; ?>>utf-8</option>
<option value='UE' <?php if($to=="UE") echo "selected='selected'"; ?>>Unicode entities</option>
</select>
<input type='submit' />

<a
href="http://validator.w3.org/check?uri=http://pavouk.net/tools/convertor/convertor.php"><img
src='/img/vxhtml10.png' height='22'
alt='Valid XHTML 1.0 Strict' /></a> <a
href="http://jigsaw.w3.org/css-validator/validator?uri=http://pavouk.net/tools/convertor/convertor.php"><img
src="/img/vcss.gif" height='22'
alt="Valid CSS!" /></a>

<br />
In:
</td></tr><tr><td style='height:50%'>
<textarea name='text' style='width:100%;height:100%' rows='10' cols='60'><?php echo stripslashes($text); ?></textarea>
</td></tr><tr><td>
Out:
</td></tr><tr><td style='height:50%' valign='top'>
<textarea style='width:100%;height:100%' rows='10' cols='60'>
<?php
// nejdulezitejsi
$conv = new convertor;
$conv->convertor($from,$to,stripslashes($text)); 
echo htmlspecialchars($conv->pull()); 
?>
</textarea>
<br /> 

</td></tr></table>
</form>

</body>
</html>
